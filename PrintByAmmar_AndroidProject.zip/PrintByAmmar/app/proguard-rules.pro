# Add project specific ProGuard rules here.
-keep class com.ammar.printbyammar.** { *; }
